/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import utils.DBConnection;
import utils.Hash;

/**
 *
 * @author AndreiSui
 */
public class UsersDAO {

    private Connection connection;
    private static UsersDAO instance;

    public static UsersDAO getInstance() {
        if (instance == null) {
            instance = new UsersDAO();
        }
        return instance;
    }

    private UsersDAO() {
    }

    public boolean userExists(String username) {
        connection = DBConnection.getConnection();
        try {
            System.out.println("BEFORE QUERY");
            PreparedStatement prepStmt
                    = connection.prepareStatement("SELECT * from user u where u.username = ?");
            prepStmt.setString(1, username);
            ResultSet rs = prepStmt.executeQuery();
            //result set is empty if there are no users with the same username
            if (rs.next()) {
                rs.close();
                return true;
            }
            System.out.println("AFTER QUEYR");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isPasswordCorrect(String username, String password) {
        connection = DBConnection.getConnection();
        try {
            PreparedStatement prepStmt
                    = connection.prepareStatement("select * from user u where u.user = ? and u.password = ?");
            prepStmt.setString(1, username);
            prepStmt.setString(2, password);
//            prepStmt.setString(2, Hash.getHash(password));
            ResultSet rs = prepStmt.executeQuery();
            if (rs.next()) {
                rs.close();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
